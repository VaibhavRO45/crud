const harry = require("./second")

console.log("Hello World",harry) 
//npm i -g nodemon 19:40

