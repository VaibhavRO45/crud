const express = require('express');

const path = require("path");
const app = express();
const hbs = require("hbs");
require("./db/conn");
const Register = require("./modles/registers");
const port = process.env.PORT || 3000;


const static_path = path.join(__dirname, "../public")
const template_path = path.join(__dirname, "../templete/views")
const partials_path = path.join(__dirname, "../templete/partials")

app.use(express.json());
app.use(express.urlencoded({extended:false}));

//console.log(path.join(__dirname, "../public"))
app.use(express.static(static_path))

app.set("view engine", "hbs")
app.set("views",template_path)
hbs.registerPartials(partials_path)
app.get('/', (req, res) => {
  res.render("index")
});
/*
app.get('/login', (req, res) => {
  res.render("login")
});
*/
app.get('/register', (req, res) => {
  res.render("register")
});
/*
app.post('/login', async(req, res) => {
  try{
    console.log(req.body.Name);
    res.send(req.body.Name)
  } catch(error){
    res.status(400).send(error);

  }

});
*/
app.post('/register', async(req, res) => {
  try{
    const Password = req.body.Password;
    const CPassword = req.body.CPassword;
    if(Password === CPassword){
      const registerUser = new Register({
        Name : req.body.Name,
        Email : req.body.Email,
        DOB : req.body.DOB,
        Password : req.body.Password,
        CPassword : req.body.CPassword,
      })

      const registered = await registerUser.save();
      res.status(201).render("index");
    }

    else{
      res.send("password not matching");
    }
   /* console.log(req.body.Name);
    res.send(req.body.Name)*/
  } catch(error){
    res.status(400).send(error);

  }

});
app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
})