const mongoose = require("mongoose");

const registerSchema = new mongoose.Schema({
    Name :{
        type:String,
        required:true
    },
    Email :{
        type:String,
        required:true,
        unique:true
    },
    DOB :{
        type:String,
        required:true
    },
    Password :{
        type:String,
        required:true
    },
    CPassword :{
        type:String,
        required:true
    }
})

const Register = new mongoose.model("Register", registerSchema);

module.exports  = Register;